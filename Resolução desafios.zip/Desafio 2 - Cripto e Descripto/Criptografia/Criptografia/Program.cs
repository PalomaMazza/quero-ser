﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        while (true)
        {
            Console.WriteLine("Escolha uma opção:");
            Console.WriteLine("1. Criptografar arquivo");
            Console.WriteLine("2. Descriptografar arquivo");
            Console.WriteLine("3. Sair");
            int choice = int.Parse(Console.ReadLine());

            if (choice == 3)
            {
                Console.WriteLine("Encerrando o programa.");
                break;
            }

            if (choice < 1 || choice > 3)
            {
                Console.WriteLine("Opção inválida. Escolha 1, 2 ou 3.");
                continue;
            }

            if (choice == 1 || choice == 2)
            {
                //Entrada do caminho do arquivo de entrada e saída
                Console.Write("Digite o caminho completo do arquivo de entrada: ");
                string inputFilePath = Console.ReadLine();

                Console.Write("Digite o diretório onde o arquivo de saída será salvo: ");
                string outputDirectory = Console.ReadLine();

                // Verificação se os caminhos são válidos
                if (!File.Exists(inputFilePath))
                {
                    Console.WriteLine("Arquivo de entrada não encontrado.");
                    continue;
                }

                if (!Directory.Exists(outputDirectory))
                {
                    Console.WriteLine("Diretório de saída não encontrado.");
                    continue;
                }

                //Entrada e validação do valor do deslocamento
                Console.Write("Digite o valor do deslocamento: ");
                int shift = int.Parse(Console.ReadLine());
                if (shift < 1 || shift > 25)
                {
                    Console.WriteLine("O valor do deslocamento deve estar entre 1 e 25.");
                    continue;
                }

                //Geração do nome do arquivo de saída
                string outputFileName = GenerateOutputFileName(inputFilePath, choice);
                string outputFilePath = Path.Combine(outputDirectory, outputFileName);

                if (choice == 1)
                {
                    //Criptografar e salvar o arquivo
                    EncryptFile(inputFilePath, outputFilePath, shift);
                    Console.WriteLine("Arquivo criptografado com sucesso!");
                }
                else if (choice == 2)
                {
                    //Descriptografar e salvar o arquivo
                    DecryptFile(inputFilePath, outputFilePath, shift);
                    Console.WriteLine("Arquivo descriptografado com sucesso!");
                }
            }
        }
    }
    static string GenerateOutputFileName(string inputFilePath, int choice)
    {
        string action = choice == 1 ? "criptografado" : "descriptografado";
        string baseFileName = Path.GetFileNameWithoutExtension(inputFilePath);
        string extension = Path.GetExtension(inputFilePath);

        return $"{baseFileName}_{action}{extension}";
    }
    static void EncryptFile(string inputPath, string outputPath, int shift)
    {
        using (StreamReader reader = new StreamReader(inputPath))
        using (StreamWriter writer = new StreamWriter(outputPath))
        {
            while (!reader.EndOfStream)
            {
                char character = (char)reader.Read();
                char encryptedChar = EncryptCharacter(character, shift);
                writer.Write(encryptedChar);
            }
        }
    }
    static void DecryptFile(string inputPath, string outputPath, int shift)
    {
        using (StreamReader reader = new StreamReader(inputPath))
        using (StreamWriter writer = new StreamWriter(outputPath))
        {
            while (!reader.EndOfStream)
            {
                char character = (char)reader.Read();
                char decryptedChar = DecryptCharacter(character, shift);
                writer.Write(decryptedChar);
            }
        }
    }
    static char EncryptCharacter(char character, int shift)
    {
        // Considerando letras maiúsculas
        if (char.IsUpper(character))
        {
            return (char)(((character - 'A' + shift) % 26) + 'A');
        }
        // Considerando letras minúsculas
        else if (char.IsLower(character))
        {
            return (char)(((character - 'a' + shift) % 26) + 'a');
        }
        // Mantém outros caracteres inalterados
        return character;
    }
    static char DecryptCharacter(char character, int shift)
    {
        // Considerando letras maiúsculas
        if (char.IsUpper(character))
        {
            return (char)(((character - 'A' - shift + 26) % 26) + 'A');
        }
        // Considerando letras minúsculas
        else if (char.IsLower(character))
        {
            return (char)(((character - 'a' - shift + 26) % 26) + 'a');
        }
        // Mantém outros caracteres inalterados
        return character;
    }
}
