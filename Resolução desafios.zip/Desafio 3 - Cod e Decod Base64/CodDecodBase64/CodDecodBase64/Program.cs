﻿using System;
using System.IO;
using System.Text;

namespace Base64EncoderDecoder
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o caminho do diretório onde os arquivos serão salvos:");
            string outputDirectory = Console.ReadLine();

            bool keepRunning = true;

            //Loop que permite ao usuário realizar ações repetidamente até optar por sair
            while (keepRunning)
            {
                Console.WriteLine("Deseja codificar (C), decodificar (D) ou sair (S)?");
                string choice = Console.ReadLine().ToUpper();

                switch (choice)
                {
                    case "C":
                        Console.WriteLine("Digite o caminho do arquivo a ser codificado:");
                        string inputFilePath = Console.ReadLine();

                        //Gera automaticamente o caminho para o arquivo codificado
                        string encodedFilePath = Path.Combine(outputDirectory, "encoded.txt");

                        //Codifica o arquivo de entrada para Base64 e escreve o resultado no arquivo de saída
                        if (File.Exists(inputFilePath))
                        {
                            EncodeFile(inputFilePath, encodedFilePath);
                            Console.WriteLine("Arquivo codificado com sucesso no caminho " + outputDirectory + "\\encoded.txt!");
                        }
                        else
                        {
                            Console.WriteLine("Arquivo não encontrado.");                            
                        }
                        break;

                    case "D":
                        Console.WriteLine("Digite o caminho do arquivo codificado a ser decodificado:");
                        string encodedInputFilePath = Console.ReadLine();

                        //Gera automaticamente o caminho para o arquivo decodificado
                        string decodedFilePath = Path.Combine(outputDirectory, "decoded.txt");

                        //Decodifica o arquivo codificado em Base64 para bytes e escreve o resultado no arquivo de saída
                        if (File.Exists(encodedInputFilePath))
                        {
                            DecodeFile(encodedInputFilePath, decodedFilePath);
                            Console.WriteLine("Arquivo decodificado com sucesso no caminho " + outputDirectory + "\\decoded.txt");
                        }
                        else
                        {
                            Console.WriteLine("Arquivo não encontrado.");
                        }
                        break;

                    case "S":
                        Console.WriteLine("Encerrando o programa.");
                        keepRunning = false;
                        break;

                    default:
                        Console.WriteLine("Escolha inválida. Tente novamente.");
                        break;
                }
            }
        }

        static void EncodeFile(string inputFilePath, string encodedFilePath)
        {
            //Lê os bytes do arquivo de entrada
            byte[] inputFileBytes = File.ReadAllBytes(inputFilePath);

            //Converte os bytes em uma string Base64 personalizada
            string base64Encoded = CustomBase64Encode(inputFileBytes);

            //Escreve a string Base64 no arquivo de saída
            File.WriteAllText(encodedFilePath, base64Encoded);
        }

        static void DecodeFile(string encodedInputFilePath, string decodedFilePath)
        {
            //Lê a string Base64 do arquivo codificado
            string base64Encoded = File.ReadAllText(encodedInputFilePath);

            //Converte a string Base64 em bytes usando a função de decodificação personalizada
            byte[] decodedBytes = CustomBase64Decode(base64Encoded);

            //Escreve os bytes decodificados no arquivo de saída
            File.WriteAllBytes(decodedFilePath, decodedBytes);
        }

        static string CustomBase64Encode(byte[] bytes)
        {
            //Tabela de caracteres Base64 padrão
            const string base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

            //Variável para armazenar o resultado codificado
            StringBuilder result = new StringBuilder();

            int byteIndex = 0;

            //Percorre pelos bytes de entrada em grupos de 3 bytes
            while (byteIndex < bytes.Length)
            {
                //Coleta os três bytes a serem codificados (ou menos, se estiver no final)
                byte b1 = bytes[byteIndex++];
                byte b2 = (byteIndex < bytes.Length) ? bytes[byteIndex++] : (byte)0;
                byte b3 = (byteIndex < bytes.Length) ? bytes[byteIndex++] : (byte)0;

                //Divide os 24 bits em quatro grupos de 6 bits
                int index1 = b1 >> 2;
                int index2 = ((b1 & 0x03) << 4) | (b2 >> 4);
                int index3 = ((b2 & 0x0F) << 2) | (b3 >> 6);
                int index4 = b3 & 0x3F;

                //Converte os índices em caracteres da tabela Base64 e adiciona ao resultado
                result.Append(base64Chars[index1]);
                result.Append(base64Chars[index2]);
                result.Append(base64Chars[index3]);
                result.Append(base64Chars[index4]);
            }

            //Calcula o número de caracteres de preenchimento necessários
            int paddingLength = bytes.Length % 3;

            //Adiciona caracteres de preenchimento, se necessário
            if (paddingLength > 0)
            {
                result[result.Length - 1] = '=';
                if (paddingLength == 1)
                {
                    result[result.Length - 2] = '=';
                }
            }

            //Retorna a string codificada em Base64
            return result.ToString();
        }


        static byte[] CustomBase64Decode(string base64)
        {
            const string base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

            //Remove caracteres de preenchimento
            base64 = base64.TrimEnd('=');

            //Calcula o tamanho aproximado dos bytes decodificados
            int estimatedSize = (base64.Length * 6) / 8;
            List<byte> decodedBytes = new List<byte>(estimatedSize);

            int charIndex = 0;

            //Percorre pelos caracteres da string Base64 em grupos de 4 caracteres
            while (charIndex < base64.Length)
            {
                if (charIndex + 3 <= base64.Length)
                {
                    //Coleta os quatro caracteres a serem decodificados
                    char char1 = base64[charIndex++];
                    char char2 = base64[charIndex++];
                    char char3 = base64[charIndex++];
                    char char4 = base64[charIndex++];                

                    //Converte os caracteres para índices na tabela Base64
                    int index1 = base64Chars.IndexOf(char1);
                    int index2 = base64Chars.IndexOf(char2);
                    int index3 = base64Chars.IndexOf(char3);
                    int index4 = base64Chars.IndexOf(char4);

                    //Combina os 4 grupos de 6 bits em 3 bytes
                    byte byte1 = (byte)((index1 << 2) | (index2 >> 4));
                    byte byte2 = (byte)((index2 << 4) | (index3 >> 2));
                    byte byte3 = (byte)((index3 << 6) | index4);

                    //Adiciona os bytes decodificados à lista
                    decodedBytes.Add(byte1);
                    if (char3 != '=')
                        decodedBytes.Add(byte2);
                    if (char4 != '=')
                        decodedBytes.Add(byte3);
                }
                else
                {
                    break;
                }
            }

            //Converte a lista de bytes para um array
            return decodedBytes.ToArray();
        }

    }
}
