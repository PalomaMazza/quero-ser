﻿using System;
using System.IO;
using System.Collections.Generic;

namespace IntersectFilesApp
{
    class Program
    {
        static void Main(string[] args)
        {
            bool continueRunning = true;

            while (continueRunning)
            {
                //Solicita ao usuário que insira os caminhos dos arquivos de entrada
                Console.WriteLine("Digite o caminho do primeiro arquivo, exemplo 'C:\\caminho\\arquivo.txt' (ou 'sair' para encerrar):");
                string inputFile1 = Console.ReadLine();

                if (inputFile1.ToLower() == "sair")
                {
                    continueRunning = false;
                    continue;
                }

                Console.WriteLine("Digite o caminho do segundo arquivo, exemplo 'C:\\caminho\\arquivo.txt' (ou 'sair' para encerrar):");
                string inputFile2 = Console.ReadLine();

                if (inputFile2.ToLower() == "sair")
                {
                    continueRunning = false;
                    continue;
                }

                //Solicita ao usuário que insira o caminho onde o arquivo de saída deve ser gravado
                Console.WriteLine("Digite o caminho onde o arquivo de saída deve ser gravado (ou 'sair' para encerrar):");
                string outputFolderPath = Console.ReadLine();

                if (outputFolderPath.ToLower() == "sair")
                {
                    continueRunning = false;
                    continue;
                }

                try
                {
                    //Tenta ler e processar os arquivos
                    List<string> lines1 = ReadFile(inputFile1);
                    List<string> lines2 = ReadFile(inputFile2);

                    //Encontra a interseção entre as linhas dos dois arquivos
                    List<string> intersection = FindIntersection(lines1, lines2);

                    //Gera o nome do arquivo de saída automaticamente
                    string outputFileName = GenerateOutputFileName();

                    //Combina o caminho da pasta de saída com o nome do arquivo de saída
                    string outputFile = Path.Combine(outputFolderPath, outputFileName);

                    //Escreve a interseção no arquivo de saída
                    WriteToFile(outputFile, intersection);

                    Console.WriteLine("Interseção das linhas gravada em " + outputFile);
                }
                catch (IOException e)
                {
                    Console.WriteLine("Erro ao processar os arquivos, favor verificar se o caminho está correto, caso esteja, tente enviar um arquivo em um formato de texto diferente.");
                }

                //Solicita ao usuário se deseja fazer outra interseção
                Console.WriteLine("Deseja fazer outra interseção? (S/N)");
                string choice = Console.ReadLine().ToUpper();
                if (choice != "S")
                {
                    continueRunning = false;
                }
            }
        }

        //Lê as linhas de um arquivo e retorna uma lista de strings
        static List<string> ReadFile(string filePath)
        {
            List<string> lines = new List<string>();

            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    lines.Add(line);
                }
            }

            return lines;
        }

        //Encontra a interseção entre duas listas de strings
        static List<string> FindIntersection(List<string> list1, List<string> list2)
        {
            List<string> intersection = new List<string>();

            foreach (string line in list1)
            {
                if (list2.Contains(line))
                {
                    intersection.Add(line);
                    list2.Remove(line);
                }
            }

            return intersection;
        }

        //Escreve as linhas em um arquivo
        static void WriteToFile(string filePath, List<string> lines)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (string line in lines)
                {
                    writer.WriteLine(line);
                }
            }
        }

        //Gera um nome de arquivo de saída baseado na data e hora atual
        static string GenerateOutputFileName()
        {
            string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
            string outputFileName = $"intersection_output_{timestamp}.txt";
            return outputFileName;
        }
    }
}
