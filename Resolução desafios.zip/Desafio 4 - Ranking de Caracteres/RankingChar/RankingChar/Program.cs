﻿using System;
using System.Collections.Generic;
using System.IO;

namespace CharacterRankingApp
{
    class Program
    {
        static Dictionary<char, int> CountCharacters(string text)
        {
            //Dicionário para armazenar a contagem de cada caractere
            Dictionary<char, int> characterCount = new Dictionary<char, int>();

            //Percorre cada caractere no texto
            foreach (char c in text)
            {
                //Verifica se o caractere já existe no dicionário
                if (characterCount.ContainsKey(c))
                {
                    //Se existir, incrementa a contagem
                    characterCount[c]++;
                }
                else
                {
                    //Se não existir, adiciona ao dicionário com contagem 1
                    characterCount[c] = 1;
                }
            }

            return characterCount;
        }

        static List<KeyValuePair<char, int>> SortRanking(Dictionary<char, int> characterCount)
        {
            //Lista para armazenar o ranking de caracteres
            List<KeyValuePair<char, int>> ranking = new List<KeyValuePair<char, int>>();

            //Enquanto ainda houver caracteres no dicionário,
            //Percorre pelo dicionário para encontrar o caractere com maior contagem
            while (characterCount.Count > 0)
            {
                int maxCount = -1;
                char maxChar = '\0';

                foreach (var kvp in characterCount)
                {
                    if (kvp.Value > maxCount)
                    {
                        maxCount = kvp.Value;
                        maxChar = kvp.Key;
                    }
                }

                //Adiciona o caractere com maior contagem ao ranking
                ranking.Add(new KeyValuePair<char, int>(maxChar, maxCount));

                //Remove o caractere do dicionário
                characterCount.Remove(maxChar);
            }

            return ranking;
        }

        static void Main(string[] args)
        {
            bool continueRunning = true;

            //Loop principal que permite que o usuário teste vários arquivos
            while (continueRunning)
            {
                Console.Write("Digite o caminho do arquivo de texto, exemplo 'C:\\caminho\\arquivo.txt' (ou 'sair' para encerrar): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "sair")
                {
                    continueRunning = false;
                    continue;
                }

                try
                {
                    //Lê o conteúdo do arquivo
                    string text = File.ReadAllText(input);

                    //Conta a quantidade de cada caractere no texto
                    Dictionary<char, int> characterCount = CountCharacters(text);

                    //Monta o ranking de caracteres baseado na contagem
                    List<KeyValuePair<char, int>> ranking = SortRanking(characterCount);

                    Console.WriteLine("Ranking de caracteres:");
                    foreach (var kvp in ranking)
                    {
                        Console.WriteLine($"'{kvp.Key}': {kvp.Value}");
                    }
                }
                catch (FileNotFoundException)
                {
                    Console.WriteLine("Arquivo não encontrado.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ocorreu um erro: {ex.Message}");
                }
            }
        }
    }
}
