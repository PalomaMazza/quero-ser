﻿using System;

namespace BigIntMultiplication
{
    class Program
    {
        //Função para realizar a adição de dois números grandes representados como strings
        static string AddStrings(string num1, string num2)
        {
            int carry = 0;
            int i = num1.Length - 1;
            int j = num2.Length - 1;
            string result = "";

            //Percorre os dígitos de ambos os números e adiciona os dígitos mais baixos
            //junto com o carry (vai sobrando quando a soma é maior que 9)
            while (i >= 0 || j >= 0 || carry > 0)
            {
                int digit1 = i >= 0 ? num1[i] - '0' : 0;
                int digit2 = j >= 0 ? num2[j] - '0' : 0;

                int sum = digit1 + digit2 + carry;
                carry = sum / 10;
                int digitSum = sum % 10;

                result = digitSum + result;

                i--;
                j--;
            }

            return result;
        }

        //Função para realizar a multiplicação de dois números grandes representados como strings
        static string MultiplyStrings(string num1, string num2)
        {
            int m = num1.Length;
            int n = num2.Length;
            int[] resultArray = new int[m + n];

            // Percorre os dígitos dos números da direita para a esquerda, multiplicando-os
            for (int i = m - 1; i >= 0; i--)
            {
                for (int j = n - 1; j >= 0; j--)
                {
                    int product = (num1[i] - '0') * (num2[j] - '0');
                    int p1 = i + j;
                    int p2 = i + j + 1;

                    int sum = product + resultArray[p2];
                    resultArray[p1] += sum / 10;
                    resultArray[p2] = sum % 10;
                }
            }

            //Converte o array de resultados em uma string final
            string result = "";
            foreach (int digit in resultArray)
            {
                if (!(result.Length == 0 && digit == 0))
                {
                    result += digit;
                }
            }

            return result.Length == 0 ? "0" : result;
        }

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Digite 'sair' para encerrar o programa.");

                //Solicita ao usuário os dois números para a multiplicação
                Console.Write("Digite o primeiro número: ");
                string num1 = Console.ReadLine();

                if (num1.ToLower() == "sair")
                {
                    break;
                }

                Console.Write("Digite o segundo número: ");
                string num2 = Console.ReadLine();

                if (num2.ToLower() == "sair")
                {
                    break;
                }

                //Realiza a multiplicação dos números e exibe o resultado
                string multiplicationResult = MultiplyStrings(num1, num2);
                Console.WriteLine($"Resultado da Multiplicação: {multiplicationResult}");
            }
        }
    }
}
